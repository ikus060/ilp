/* File glpk_java.i
 * 
 * This file contains definitions that are needed for compiling code explicitly
 * added to GLPK for Java, and which shall be wrapped by Swig.
 */
#ifndef GLPK_JAVA_H
#define GLPK_JAVA_H

#define GLP_JAVA_MSG_LVL_OFF 0
#define GLP_JAVA_MSG_LVL_ALL 1
void glp_java_error(char *message);
void glp_java_set_msg_lvl(int msg_lvl);

typedef struct _glp_java_arc_data glp_java_arc_data;

struct _glp_java_arc_data {
   double cap;  // arc capacity
   double cost; // arc cost
   double low;  // lower bound
   double x;    // arc flow
};

typedef struct _glp_java_vertex_data glp_java_vertex_data;

struct _glp_java_vertex_data {
   int    cut; // 0: node is unlabelled, 1: node is labelled
   double pi;  // node potential
   double rhs; // supply/demand value
   int    set; // 0: vertex is in set R, 1: vertex is in set S
};

glp_java_arc_data *glp_java_arc_get_data(const glp_arc *arc);
glp_java_vertex_data *glp_java_vertex_data_get( const glp_graph *G, const int i);
glp_java_vertex_data *glp_java_vertex_get_data( const glp_vertex *v);
glp_vertex *glp_java_vertex_get( const glp_graph *G, const int i );

#endif // GLPK_JAVA_H
