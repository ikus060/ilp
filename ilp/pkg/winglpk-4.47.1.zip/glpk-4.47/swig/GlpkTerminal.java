package org.gnu.glpk;

import java.util.LinkedList;

/**
 * This class manages terminal output.
 * <p>GLPK will call method {@link #callback(String) callback} before producing
 * terminal output. A listener can inhibit the terminal output by returning
 * <code>false</code> in the {@link GlpkTerminalListener#output(String) output}
 * routine.
 * <p>If a {@link GlpkException GlpkExeption} has occured it is necessary to
 * call <pre>
 * GLPK.glp_term_hook(null, null);</pre>
 * to reenable listening to terminal output.
 * @see GlpkTerminalListener
 * @see GlpkException
 * @see GLPK#glp_term_hook(SWIGTYPE_p_f_p_void_p_q_const__char__int,
 * SWIGTYPE_p_void)
 */
public class GlpkTerminal {
    private static LinkedList<GlpkTerminalListener> listeners
            = new LinkedList<GlpkTerminalListener>();

    static {
        GLPK.glp_term_hook(null, null);
    }

    /**
     * Callback function called by native library.
     */
    public static int callback(String str) {
        boolean output = false;

        if (listeners.size() > 0) {
            for (GlpkTerminalListener listener : listeners) {
                output |= listener.output(str);
            }
            return output ? 0 : 1;
        }
        return 0;
    }

    /**
     * Add listener.
     * @param listener listener for terminal output
     */
    public static void addListener(GlpkTerminalListener listener) {
        listeners.add(listener);
    }

    /**
     * Remove listener.
     * @param listener listener for terminal output
     */
    public static void removeListener(GlpkTerminalListener listener) {
        listeners.remove(listener);
    }

    /**
     * Remove all listeners.
     */
    public static void removeAllListeners() {
        while( listeners.size() > 0) {
            listeners.removeLast();
        }
    }
}
